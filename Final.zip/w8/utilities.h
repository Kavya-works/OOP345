/***********************************************************************
// OOP345 Workshop #8
//
// File w8_p2.cpp
// -----------------------------------------------------------
// Name: Kavya Shah 
   Date: 24-03-2024
   Email: kbshah6@myseneca.ca  
   Student ID: 140055229
   Reason: I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.
***********************************************************************/
#ifndef SENECA_UTILITIES_H
#define SENECA_UTILITIES_H

#include "list.h"
#include "element.h"

namespace seneca {
	List<Product> mergeRaw(const List<Description>& desc, const List<Price>& price);
	List<Product> mergeSmart(const List<Description>& desc, const List<Price>& price);
}

#endif