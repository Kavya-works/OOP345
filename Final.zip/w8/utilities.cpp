/***********************************************************************
// OOP345 Workshop #8
//
// File w8_p2.cpp
// -----------------------------------------------------------
// Name: Kavya Shah 
   Date: 24-03-2024
   Email: kbshah6@myseneca.ca  
   Student ID: 140055229
   Reason: I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.
***********************************************************************/

#include <memory>
#include "list.h"
#include "element.h"
#include "utilities.h"

using namespace std;

// Complete the mergeSmart() function in the Utilities module using smart pointer syntax

namespace seneca
{
    List<Product> mergeRaw(const List<Description>& desc, const List<Price>& price)
    {
        List<Product> priceList;
        // TODO: Add your code here to build a list of products
        //         using raw pointers

        for (unsigned int i = 0; i < desc.size(); i++)
        {
            for (unsigned int j = 0; j < price.size(); j++)
            {
                if (desc[i].code == price[j].code)
                {
                    Product* product = new Product(desc[i].desc, price[j].price);
                    if (!(desc[i].code))
                    {
                        delete product;
                        throw std::string("*** Negative prices are invalid ***");
                    }
                    else
                    {
                        try
                        {
                            product->validate();
                        }
                        catch (std::string err)
                        {
                            delete product;
                            throw std::string(err);
                        }
                    }
                    priceList += product;
                    delete product;
                }
            }
        }

        return priceList;
    }

    List<Product> mergeSmart(const List<Description>& desc, const List<Price>& price)
    {
        List<Product> priceList;
        // TODO: Add your code here to build a list of products
        //         using smart pointers
        for (unsigned int i = 0; i < desc.size(); i++)
        {

            for (unsigned int j = 0; j < price.size(); j++)
            {

                if (desc[i].code == price[j].code)
                {
                    std::unique_ptr<Product> product = std::make_unique<Product>(desc[i].desc, price[j].price);

                    if (!(desc[i].code))
                    {
                        throw std::string("*** Negative prices are invalid ***");
                    }
                    else
                    {
                        product.get()->validate();
                    }

                    priceList += product;
                }
            }
        }

        return priceList;
    }
}