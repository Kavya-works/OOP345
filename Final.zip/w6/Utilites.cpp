#include "Employee.h"
#include "Student.h"
#include "Professor.h"
#include "Utilities.h"
#include "Person.h"

namespace seneca
{
    Person* buildInstance(std::istream& in)
    {
        char ch{};
        Person* p{};
        in >> ch;
        in.ignore();
        if (ch == 'e' || ch == 'E')
            p = new Employee(in);
        else if (ch == 's' || ch == 'S')
            p = new Student(in);
        else if (ch == 'p' || ch == 'P')
            p = new Professor(in);
        return p;
    }
}