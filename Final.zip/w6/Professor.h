#ifndef SENECA_PROFESSOR_H
#define SENECA_PROFESSOR_H

#include <iostream>
#include <string>
#include "Employee.h"

namespace seneca
{
    class Professor : public Employee
    {
        std::string m_department{};
        // trim 'whitespace' from begining and end of 'str'
        static std::string trim(const std::string& str,
            const std::string& whitespace)
        {
            const auto strBegin = str.find_first_not_of(whitespace);
            if (strBegin == std::string::npos)
                return ""; // no content
            const auto strEnd = str.find_last_not_of(whitespace);
            const auto strRange = strEnd - strBegin + 1;
            return str.substr(strBegin, strRange);
        }
    public:
        Professor(std::istream& is = std::cin);
        void display(std::ostream& os) const;
        std::string status() const;
        std::string department() const;
    };
}
#endif
