//************************************************
//
// Name : Kavya Shah
// Class : OOP345 
// ID : 140055229
// Mail : kbshah6@myseneca.ca
//
//************************************************
#include <iostream>
#include <string>
#include "Movie.h"
#include "iomanip"

using namespace std;

namespace sdds
{

    Movie::Movie(const string& strMovie)
    {

        size_t start = 0, end = strMovie.find(',');
        //
        title_ = strMovie.substr(start, end - start);
        title_.erase(0, title_.find_first_not_of(' '));
        title_.erase(title_.find_last_not_of(' ') + 1);
        //
        //
        start = end + 1;
        end = strMovie.find(',', start);
        //
        year = stoi(strMovie.substr(start, end - start));
        //
        start = end + 1;
        description = strMovie.substr(start);
        //
        description.erase(0, description.find_first_not_of(' '));
        description.erase(description.find_last_not_of(' ') + 1);
    }
    //
    //
    const string& Movie::title() const
    {
        return title_;
    }
    //
    //
    bool Movie::operator==(const Movie& obj)
    {
        return (title_ == obj.title_ && year == obj.year && description == obj.description);
    }
    //
    //
    ostream& operator<<(ostream& ostr, const Movie& obj) {
        ostr << right << setw(40) << obj.title_ << " | " << obj.year << " | " << left << obj.description;
        return ostr;
    }
    //
    void  Movie::fixSpelling(SpellChecker& spellChecker) {
        spellChecker(title_);
        spellChecker(description);
    }
}
