#pragma once
//************************************************
//
// Name : Kavya Shah
// Class : OOP345 
// ID : 140055229
// Mail : kbshah6@myseneca.ca
//
//************************************************
#ifndef SDDS_BOOK_H 
#define SDDS_BOOK_H

#include <iostream>
#include <string>
#include "SpellChecker.h"
//
namespace sdds
{
    class Book
    {
        std::string Author = "";
        std::string Title = "";
        std::string Country = "";
        size_t _year = 0;
        double _price = 0.0;
        std::string Description = "";

    public:

        Book() = default;
        Book(const std::string& strBook);
        //
        //
        //
        const std::string& title() const;
        const std::string& country() const;
        const size_t& year() const;
        double& price();

        void fixSpelling(SpellChecker&);


        bool operator==(const Book&);

        friend std::ostream& operator<<(std::ostream& os, const Book& book);
    };
}

#endif // !SDDS_BOOK_H
