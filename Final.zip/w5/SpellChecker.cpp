//************************************************
//
// Name : Kavya Shah
// Class : OOP345 
// ID : 140055229
// Mail : kbshah6@myseneca.ca
//
//************************************************
#include <iostream>
#include <string>
#include "SpellChecker.h"
#include <fstream>
#include "iomanip"

using namespace std;

namespace sdds
{

    SpellChecker::SpellChecker(const char* filename)
    {
        ifstream file(filename);
        if (!file)
            throw std::runtime_error("Bad file name!");
        //
        //
        //
        string line;
        for (size_t i = 0; i < 6 && getline(file, line); i++)
        {
            size_t index = line.find(' ');
            m_badWords[i] = line.substr(0, index);
            m_goodWords[i] = line.substr(index + 1);
            m_goodWords[i].erase(0, m_goodWords[i].find_first_not_of(' '));
        }
    }

    //
        //
        //
    void SpellChecker::operator()(string& text) {
        //
        for (size_t i = 0; i < 6; i++) {
            size_t index = 0;
            while ((index = text.find(m_badWords[i], index)) != string::npos) {
                text.replace(index, m_badWords[i].length(), m_goodWords[i]);
                m_replacementCount[i]++;
            }
        }
    }
    //
    //
    //
    void SpellChecker::showStatistics(ostream& os) const {
        os << "Spellchecker Statistics" << endl;

        for (size_t i = 0; i < 6; i++) {
            os << right << setw(15) << m_badWords[i] << ": " << m_replacementCount[i] << " replacements" << endl;
        }
    }
}
