#pragma once
//************************************************
//
// Name : Kavya Shah
// Class : OOP345 
// ID : 140055229
// Mail : kbshah6@myseneca.ca
//
//************************************************
#ifndef SDDS_MOVIE_H
#define SDDS_MOVIE_H

#include <iostream>
#include <string>
#include "SpellChecker.h"

namespace sdds {
    class Movie {
        std::string title_ = "";
        size_t year{ 0 };
        std::string description = "";

    public:
        Movie() = default;
        Movie(const std::string&);
        //
        const std::string& title() const;
        void fixSpelling(SpellChecker&);
        //
        //
        bool operator==(const Movie&);
        //
        //
        friend std::ostream& operator<<(std::ostream&, const Movie&);
    };
}

#endif
