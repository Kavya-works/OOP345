#pragma once
#ifndef SDDS_SPELLCHECKER_H
#define SDDS_SPELLCHECKER_H

//************************************************
//
// Name : Kavya Shah
// Class : OOP345 
// ID : 140055229
// Mail : kbshah6@myseneca.ca
//************************************************
#include <iostream>
#include <string>

namespace sdds
{
    class SpellChecker
    {
    private:
        std::string m_badWords[6];
        std::string m_goodWords[6];
        int m_replacementCount[6]{ 0 };
        //
    public:
        SpellChecker() = default;
        SpellChecker(const char*);
        //
        //
        void operator()(std::string&);
        void showStatistics(std::ostream&) const;
    };
}

#endif 
