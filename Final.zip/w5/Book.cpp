//************************************************
//
// Name : Kavya Shah
// Class : OOP345 
// ID : 140055229
// Mail : kbshah6@myseneca.ca
//
//************************************************
#include "Book.h"
#include <iostream>
#include <iomanip>

using namespace std;

namespace sdds
{

    Book::Book(const string& strBook)
    {

        size_t start = 0, end = strBook.find(',');
        //
        Author = strBook.substr(start, end - start);
        Author.erase(0, Author.find_first_not_of(' '));
        Author.erase(Author.find_last_not_of(' ') + 1);
        //
        //
        start = end + 1; end = strBook.find(',', start);
        //
        Title = strBook.substr(start, end - start);
        Title.erase(0, Title.find_first_not_of(' '));
        Title.erase(Title.find_last_not_of(' ') + 1);
        //
        //
        start = end + 1; end = strBook.find(",", start);
        //
        Country = strBook.substr(start, end - start);
        Country.erase(0, Country.find_first_not_of(' '));
        Country.erase(Country.find_last_not_of(' ') + 1);
        //
        start = end + 1; end = strBook.find(",", start);
        _price = stod(strBook.substr(start, end - start));
        //
        start = end + 1; end = strBook.find(",", start);
        _year = stoi(strBook.substr(start, end - start));
        ///
        start = end + 1; end = strBook.length();
        Description = strBook.substr(start, end - start);
        Description.erase(0, Description.find_first_not_of(' '));
        Description.erase(Description.find_last_not_of(' ') + 1);
    }
    //
    //
    const string& Book::title() const { return  Title; }
    const string& Book::country() const { return Country; }
    const size_t& Book::year() const { return _year; }
    double& Book::price() { return _price; }
    //
    //
    ostream& operator<<(ostream& ostr, const Book& obj)
    {
        ostr << right << setw(20) << obj.Author << " | "
            << setw(22) << obj.Title << " | "
            << setw(5) << obj.Country << " | "
            << obj._year << " | "
            << setw(6) << fixed << setprecision(2) << obj._price << " | "
            << left << obj.Description;
        return ostr;
    }
    //
    //
    bool Book::operator==(const Book& obj)
    {
        return (Author == obj.Author && Title == obj.Title && _year == obj._year);
    }
    //
    //
    void Book::fixSpelling(SpellChecker& spellChecker)
    {
        spellChecker(Description);
        spellChecker(Author);
        spellChecker(Country);
    }
}
