#pragma once
/*
======================================
Workshop 3 Part 2
======================================
Name : Kavya Shah
Student ID : 140055229
Student Email : kbshah6@myseneca.ca
Date : 04 / 02 / 2024
Section : ZBB
------------------------------------ -
I have done all the coding by myself and only copied the code that my
professor provided to complete my workshops and assignments.
======================================
*/

#ifndef SENECA_PAIR_H
#define SENECA_PAIR_H

#include <string>

namespace seneca
{
    class Pair
    {
        std::string m_key{};
        std::string m_value{};
    public:
        const std::string& getKey() { return m_key; }
        const std::string& getValue() { return m_value; }
        Pair(const std::string& key, const std::string& value) : m_key{ key }, m_value{ value } {};

        //TO DO:
        Pair();
        bool operator==(const Pair& P);
        std::ostream& display(std::ostream& os) const;
    };

    std::ostream& operator<<(std::ostream& os, const Pair& P);
}
#endif 