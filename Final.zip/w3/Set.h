/*
======================================
Workshop 3 Part 2
======================================
Name : Kavya Shah
Student ID : 140055229
Student Email : kbshah6@myseneca.ca
Date : 04 / 02 / 2024
Section : ZBB
------------------------------------ -
I have done all the coding by myself and only copied the code that my
professor provided to complete my workshops and assignments.
======================================
*/

#ifndef SENECA_SET_H
#define SENECA_SET_H

#include <cmath>
#include "Collection.h"

namespace seneca
{
    template <typename T>
    class Set : public Collection<T, 100> {
    public:
        bool add(const T& item);
    };

    template<typename T>
    bool Set<T>::add(const T& item) {
        bool res{}, found{};
        size_t size = this->size();
        for (auto i = 0ul; i < size && !found; ++i) {
            if ((*this)[i] == item) {
                found = true;
            }
        }
        if (!found) {
            Collection<T, 100>::add(item);
            res = true;
        }
        return res;
    }

    template<>
    bool Set<double>::add(const double& item) {
        bool res{}, found{};
        size_t size = this->size();
        for (auto i = 0ul; i < size && !found; ++i) {
            if (fabs((*this)[i] - item) < 0.01) {
                found = true;
            }
        }
        if (!found) {
            Collection<double, 100>::add(item);
            res = true;
        }
        return res;
    }
}
#endif 