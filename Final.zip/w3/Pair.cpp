/*
======================================
Workshop 3 Part 2
======================================
Name : Kavya Shah
Student ID : 140055229
Student Email : kbshah6@myseneca.ca
Date : 04 / 02 / 2024
Section : ZBB
------------------------------------ -
I have done all the coding by myself and only copied the code that my
professor provided to complete my workshops and assignments.
======================================
*/

#include <iostream>
#include <iomanip>
#include "Pair.h"

using namespace std;

namespace seneca
{
    Pair::Pair() {}

    bool Pair::operator==(const Pair& P) {
        return this->getKey() == P.m_key;
    }

    std::ostream& Pair::display(std::ostream& os) const {
        os << right << setw(20) << m_key << ": " << left << m_value;
        return os;
    }

    std::ostream& operator<<(std::ostream& os, const Pair& P) {
        return P.display(os);
    }
}