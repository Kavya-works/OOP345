//************************************************
//
// Name  : Kavya Shah
// Class : OOP345 
// ID    : 140055229
// Mail  : kbshah6@myseneca.ca
//
//************************************************
#ifndef SENECA_CHILD_H
#define SENECA_CHILD_H

#include <iostream>
#include <string>
#include "Toy.h"
//
namespace seneca
{
	class Child
	{
		std::string m_name;

		int m_age;

		Toy* m_toys{};

		size_t Total_Toys;

	public:
		//
		Child();
		Child(const Child& src);
		Child& operator=(const Child& src);
		//
		void reset();
		//
		//
		Child(Child&& src);
		Child& operator=(Child&& src);
		//
		Child(std::string name, int age, const Toy* toys[], size_t count);
		~Child();
		//
		//
		size_t size() const;
		//
		//
		friend std::ostream& operator<<(std::ostream& ostr, const Child& rhs);
	};
}
#endif
