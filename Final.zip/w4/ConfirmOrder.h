//************************************************
//
// Name  : Kavya Shah
// Class : OOP345 
// ID    : 140055229
// Mail  : kbshah6@myseneca.ca
//
//************************************************

#ifndef SENECA_CONFIRMORDER_H
#define SENECA_CONFIRMORDER_H
#include <iostream>
#include "Toy.h"

namespace seneca
{
	class ConfirmOrder
	{
		const Toy** m_toy;
		size_t MAX_Toys;
		//
	public:
		ConfirmOrder();
		ConfirmOrder(const ConfirmOrder& src);
		//
		ConfirmOrder& operator=(const ConfirmOrder& src);
		//
		~ConfirmOrder();
		//
		//
		ConfirmOrder(ConfirmOrder&& src);
		ConfirmOrder& operator=(ConfirmOrder&& src);
		//
		//
		//
		ConfirmOrder& operator+=(const Toy& toy);
		ConfirmOrder& operator-=(const Toy& toy);
		//
		//
		friend std::ostream& operator<<(std::ostream& ostr, const ConfirmOrder& rhs);
	};
}
#endif