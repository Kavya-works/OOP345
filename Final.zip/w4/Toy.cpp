//************************************************
//
// Name  : Kavya Shah
// Class : OOP345 
// ID    : 140055229
// Mail  : kbshah6@myseneca.ca
//
//************************************************

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <string>
#include <iomanip>
#include "Toy.h"

namespace seneca
{
    Toy::Toy()
    {
        ORDER_ID = 0;
        MAX_Items = 0;
        m_Price = 0;
    }
    void Toy::update(int numItems)
    {
        MAX_Items = numItems;
    }
    Toy::Toy(const std::string& toy)
    {
        std::string tempToy = toy;
        //
        size_t pos = tempToy.find(':');
        ORDER_ID = std::stoi(tempToy.substr(0, pos));
        //
        tempToy.erase(0, pos + 1);
        pos = tempToy.find(':');
        //
        m_name = tempToy.substr(0, pos);
        //
        m_name.erase(0, m_name.find_first_not_of(' '));
        m_name.erase(m_name.find_last_not_of(' ') + 1);
        //
        tempToy.erase(0, pos + 1);
        //
        pos = tempToy.find(':');
        MAX_Items = std::stoi(tempToy.substr(0, pos));
        tempToy.erase(0, pos + 1);

        m_Price = std::stod(tempToy);
    }
    //
    //
    std::ostream& operator<<(std::ostream& ostr, const Toy& rhs)
    {
        double total = rhs.m_Price * rhs.MAX_Items;
        double totalIncTax = total * rhs.TAX;

        ostr << "Toy"
            << std::setw(8) << rhs.ORDER_ID << ":"
            << std::right << std::setw(18) << rhs.m_name
            << std::setw(3) << rhs.MAX_Items
            << " items" << std::setw(8) << std::fixed << std::setprecision(2) << rhs.m_Price
            << "/item  subtotal:" << std::setw(7) << std::fixed << std::setprecision(2) << total
            << " tax:" << std::setw(6) << std::fixed << std::setprecision(2) << totalIncTax
            << " total:" << std::setw(7) << std::fixed << std::setprecision(2) << (total + totalIncTax) << std::endl;


        return ostr;
    }
}