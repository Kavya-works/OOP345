//************************************************
//
// Name  : Kavya Shah
// Class : OOP345 
// ID    : 140055229
// Mail  : kbshah6@myseneca.ca
//
//************************************************

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <iomanip>
#include <string>
#include "Child.h"
//
namespace seneca
{
	void Child::reset()
	{
		m_name = "";
		m_age = 0;
		Total_Toys = 0;
		delete[] m_toys;
		m_toys = nullptr;
	}
	//
	Child::Child()
	{
		reset();
	}
	//
	Child::Child(const Child& src)
	{
		*this = src;
	}
	//
	Child& Child::operator=(const Child& src)
	{
		if (this != &src)
		{
			Total_Toys = src.Total_Toys;
			m_name = src.m_name;
			m_age = src.m_age;
			delete[] m_toys;
			m_toys = new Toy[src.Total_Toys];
			for (size_t i = 0; i < src.Total_Toys; i++)
			{
				m_toys[i] = src.m_toys[i];
			}
		}
		return *this;
	}
	//
	Child::Child(Child&& src)
	{
		*this = std::move(src);
	}
	//
	Child& Child::operator=(Child&& src)
	{
		if (this != &src)
		{
			Total_Toys = src.Total_Toys;
			m_name = src.m_name;
			m_age = src.m_age;
			delete[] m_toys;
			m_toys = src.m_toys;
			src.m_toys = nullptr;
			src.Total_Toys = 0;
			src.m_name = "";
			src.m_age = 0;
		}
		return *this;
	}
	//
	Child::Child(std::string name, int age, const Toy* toys[], size_t count)
	{
		m_toys = new  Toy[count];
		m_name = name;
		m_age = age;
		Total_Toys = count;
		for (size_t i = 0; i < count; i++)
		{
			m_toys[i] = *toys[i];
		}

	}
	//
	Child::~Child()
	{
		delete[] m_toys;
		m_toys = nullptr;
	}
	//
	size_t Child::size() const
	{
		return Total_Toys;
	}
	//
	std::ostream& operator<<(std::ostream& ostr, const Child& rhs)
	{
		static int toyCounter = 0;
		++toyCounter;
		ostr << "--------------------------\n" <<
			"Child " << toyCounter << ": " << rhs.m_name << " " << rhs.m_age << " years old:" << std::endl;
		ostr << "--------------------------\n";
		if (rhs.Total_Toys == 0)
		{
			ostr << "This child has no toys!" << std::endl;
		}
		else
		{
			for (size_t i = 0; i < rhs.Total_Toys; i++)
			{
				ostr << rhs.m_toys[i];
			}
		}
		ostr << "--------------------------\n";
		return ostr;
	}
}