/*
======================================
 Workshop 1 Part 2
======================================
Module : event.h
-------------------------------------
Name: Kavya Shah
Student ID: 140055229
Student Email: kbshah6@myseneca.ca
Date: 21/01/2024
Section: ZBB
-------------------------------------
I have done all the coding by myself and only copied the code that my
professor provided to complete my workshops and assignments.
======================================
*/

#pragma once
#ifndef SENECA_EVENT_H
#define SENECA_EVENT_H

namespace seneca {
	extern unsigned int g_sysClock;


	class Event
	{

		char* desc;

		unsigned int start_time;

	public:
		Event();
		Event(const Event& obj2);
		Event& operator=(const Event& right_side);
		~Event(); // destructor to ensure no memory leaks happens 
		void display() const;
		void set(const char* new_desc);

	};
}

#endif